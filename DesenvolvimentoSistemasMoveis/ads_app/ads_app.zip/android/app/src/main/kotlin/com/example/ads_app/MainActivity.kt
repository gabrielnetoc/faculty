package com.example.ads_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
