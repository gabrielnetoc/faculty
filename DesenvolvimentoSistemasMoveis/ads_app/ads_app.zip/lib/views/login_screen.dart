import 'dart:developer';

import 'package:ads_app/helpers/login_helper.dart';
import 'package:ads_app/models/user.dart';
import 'package:ads_app/views/cadastro_screen.dart';
import 'package:ads_app/views/home_screen.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _telController = TextEditingController();
  final TextEditingController _senhaController = TextEditingController();

  final LoginHelper _user = LoginHelper();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      backgroundColor: Colors.grey[50],
      body: Center(
        child: Container(
          child: Column(
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  border: Border.all(width: 1, color: Colors.grey[400]!),
                  shape: BoxShape.circle,
                ),
                child: Image.asset('assets/avatar.png'),
              ),
              Center(
                child: Text(
                  "login".toUpperCase(),
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
              ),
              Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(
                      keyboardType: TextInputType.phone,
                      cursorWidth: 2.5,
                      controller: _telController,
                      decoration: InputDecoration(
                          prefixIcon: Icon(Icons.person),
                          labelText: "Telefone",
                          labelStyle:
                              TextStyle(fontSize: 18, color: Colors.black)),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Tem que preencher zé";
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 25),
                    TextFormField(
                      obscureText: true,
                      keyboardType: TextInputType.text,
                      controller: _senhaController,
                      decoration: InputDecoration(
                          prefixIcon: Icon(Icons.lock),
                          labelText: "Senha",
                          labelStyle:
                              TextStyle(fontSize: 18, color: Colors.black)),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Tem que preencher zé";
                        }
                        return null;
                      },
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    Container(
                      width: 180,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(primary: Colors.black),
                        onPressed: () async {
                          if (_formKey.currentState!.validate()) {
                            bool? log = await _user.login(User(
                                id: 0,
                                nome: "",
                                telefone: _telController.text,
                                senha: _senhaController.text));
                            if (log == true) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Home()));
                            } else {
                              final snackBar = SnackBar(
                                content: Text(
                                    "Erro ao logar, verifique suas credencias, zé!"),
                                backgroundColor: Colors.red,
                              );
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(snackBar);
                            }
                          }
                        },
                        child: Text(
                          "Acessar",
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                      ),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Não possui cadastro?',
                          style: TextStyle(color: Colors.black),
                        ),
                        TextButton(
                          onPressed: () async {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => CadastroScreen()));
                          },
                          child: Text(
                            "Cadastre-se",
                            style: TextStyle(
                              color: Colors.black,
                            ),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
